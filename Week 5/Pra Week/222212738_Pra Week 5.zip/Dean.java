/**
 * Dean
 */
public class Dean extends Employee {

  Dean(int ssNo, String name, String email) {
    super(ssNo, name, email);
  }

  @Override
  public String toString() {
    return super.toString();
  }
}
