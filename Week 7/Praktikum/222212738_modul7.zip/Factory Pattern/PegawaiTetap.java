/**
 * PegawaiTetap
 */
public class PegawaiTetap extends Pegawai {

  public PegawaiTetap(String nama) {
    setNama(nama);
    setTipe("Permanen");
    setPembayarangaji("Perbulan");
  }
}
