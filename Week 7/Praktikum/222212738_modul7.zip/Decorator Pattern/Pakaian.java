/**
 * Pakaian
 */
public interface Pakaian {
  public void pakai();
}
