/**
 * Kaos
 */
public class Kaos implements Pakaian {

  @Override
  public void pakai() {
    System.out.println("Jenis : Kaos");
  }
}
