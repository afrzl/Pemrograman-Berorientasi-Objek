/**
 * Celana
 */
public class Celana implements Pakaian {

  @Override
  public void pakai() {
    System.out.println("Jenis : Celana");
  }
}
