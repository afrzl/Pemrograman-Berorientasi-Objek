/**
 * Circle
 */
public class Circle extends Shape {
  private double radius;

  Circle(double radius) {
    this.radius = radius;
  }

  @Override
  void draw() {}
}
