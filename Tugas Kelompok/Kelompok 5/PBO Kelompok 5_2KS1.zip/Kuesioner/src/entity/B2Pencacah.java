package entity;

import java.util.Calendar;

public class B2Pencacah extends Human {

  public B2Pencacah() {}

  public B2Pencacah(String name, String no_hp, Calendar tanggal) {
    super(name, no_hp, tanggal);
  }
}
