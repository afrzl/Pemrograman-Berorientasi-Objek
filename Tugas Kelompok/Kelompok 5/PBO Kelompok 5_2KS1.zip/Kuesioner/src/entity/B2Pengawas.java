package entity;

import java.util.Calendar;

public class B2Pengawas extends Human {

  public B2Pengawas() {}

  public B2Pengawas(String name, String no_hp, Calendar tanggal) {
    super(name, no_hp, tanggal);
  }
}
