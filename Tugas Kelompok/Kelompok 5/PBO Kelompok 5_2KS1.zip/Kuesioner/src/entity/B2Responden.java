package entity;

import java.util.Calendar;

public class B2Responden extends Human {

  public B2Responden() {}

  public B2Responden(String name, String no_hp, Calendar tanggal) {
    super(name, no_hp, tanggal);
  }
}
